#!/usr/bin/env python

import os

# variables
colorBlue = "\033[01;34m{0}\033[00m"

##############################################################################################################

os.system("clear")
banner()

print "Salesforce"
print
print
sys.exit(0)
